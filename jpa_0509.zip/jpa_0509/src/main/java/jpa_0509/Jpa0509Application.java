package jpa_0509;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa0509Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpa0509Application.class, args);
	}

}
