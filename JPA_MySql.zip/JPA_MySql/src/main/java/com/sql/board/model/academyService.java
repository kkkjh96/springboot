package com.sql.board.model;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sql.board.dto.academyRequestDto;
import com.sql.board.dto.academyResponseDto;
import com.sql.board.entity.academy;
import com.sql.board.entity.academyRepository;
import com.sql.exception.CustomException;
import com.sql.exception.ErrorCode;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class academyService {

	private final academyRepository academyRepository;

	/*
	 * �Խñ� �ۼ�
	 */
	@Transactional
	public String save(final academyRequestDto params) {
		academy entity = academyRepository.save(params.toEntity());
		return entity.getId();
	}

	/*
	 * �Խñ� ����Ʈ ��ȸ
	 */
	public List<academyResponseDto> findAll() {
		Sort sort = Sort.by(Direction.DESC, "id");
		List<academy> list = academyRepository.findAll(sort);
		return list.stream().map(academyResponseDto::new).collect(Collectors.toList());
	}

	/*
	 * �Խñ� ����
	 */
	@Transactional
	public String update(final String id, final academyRequestDto params) {
		academy entity = academyRepository.findById(id)
				.orElseThrow(() -> new CustomException(ErrorCode.POSTS_NOT_FOUND));
		return id;
	}
}
