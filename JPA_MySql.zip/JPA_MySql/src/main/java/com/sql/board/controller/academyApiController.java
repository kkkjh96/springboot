package com.sql.board.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sql.board.dto.academyRequestDto;
import com.sql.board.dto.academyResponseDto;
import com.sql.board.model.academyService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class academyApiController {
	
	/*
	 * �Խñ� ����
	 */
	@PostMapping("/boards")
	public String save(@RequestBody final academyRequestDto params) {
		return academyService.save(params);
	}
	
	/*
	 * �Խñ� ����Ʈ ��ȸ
	 */
	@GetMapping("/boards")
	public List<academyResponseDto> findAll(){
		return academyService.findAll();
	}
	
	/*
	 * �Խñ� ����
	 */
	@PatchMapping("/boards/{id}")
	public String save(@PathVariable final String id, @RequestBody final academyRequestDto params) {
		return academyService.update(id, params);
	}
}
