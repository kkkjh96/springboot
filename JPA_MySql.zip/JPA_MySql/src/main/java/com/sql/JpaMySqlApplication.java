package com.sql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaMySqlApplication.class, args);
	}

}
