package com.academyinfo.image.controller;

public interface ImageController {

}
