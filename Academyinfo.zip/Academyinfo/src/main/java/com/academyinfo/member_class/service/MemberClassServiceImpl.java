package com.academyinfo.member_class.service;

public class MemberClassServiceImpl implements MemberClassService {

}
