package com.academyinfo.member_class.service;

public interface MemberClassService {

}
