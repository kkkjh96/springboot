package com.academyinfo.member_class.controller;

public class MemberClassControllerImpl implements MemberClassController {

}
