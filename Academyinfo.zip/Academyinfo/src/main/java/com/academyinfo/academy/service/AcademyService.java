package com.academyinfo.academy.service;

import com.academyinfo.academy.dto.AcademyRequestDto;
import com.academyinfo.member.domain.entity.MemberEntity;



public interface AcademyService {

	public Integer saveAcademy(AcademyRequestDto academyDto);
	
	public void saveAcademyInfo(Long mindex, AcademyRequestDto academyDto);
	

}
