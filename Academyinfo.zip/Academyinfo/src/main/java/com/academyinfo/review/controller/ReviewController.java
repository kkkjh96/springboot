package com.academyinfo.review.controller;

public interface ReviewController {

}
